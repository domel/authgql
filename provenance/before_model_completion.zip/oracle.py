"""Independent, deliberately small oracle: no imports from authgql.

It consumes dictionaries and enumerates bounded walks by Cartesian products,
not executor adjacency expansion. Policies are equality predicates over `flag`.
It covers only this generated sublanguage, not the complete query parser.
"""
from collections import Counter
from itertools import product


def identities(catalog, user):
    roles = set(catalog['user_roles'].get(user, []))
    while True:
        grown = roles | {parent for r in roles for parent in catalog['roles'][r]}
        if grown == roles:
            return {('USER', user)} | {('ROLE', r) for r in roles}
        roles = grown


def allowed(catalog, user, element, kind):
    who = identities(catalog, user)
    # Generator guarantees a broad permit, with optional node-label denials.
    for f in catalog['privileges']:
        if (f.get('grantee_kind', 'USER'), f['grantee']) not in who:
            continue
        if f.get('effect') == 'DENY' and kind == 'NODE':
            if set(f['target'].get('labels', [])).intersection(element['labels']):
                return False
    scope = []
    for p in catalog['policies']:
        if not p.get('enabled', True) or 'TRAVERSE' not in p['actions']:
            continue
        selector = p['selector']
        if selector['kind'] != kind:
            continue
        if kind == 'NODE' and not set(selector['labels']).intersection(element['labels']):
            continue
        if kind == 'EDGE' and element['type'] not in selector['edge_types']:
            continue
        scope.append(p)
    if not scope:
        return True
    relevant = [p for p in scope if any(
        (p['grantee_kinds'][name], name) in who for name in p['grantees'])]
    values = []
    for p in relevant:
        spec = p['using']
        if isinstance(spec, bool):
            truth = spec
        else:
            observed = element.get('properties', {}).get('flag')
            truth = None if observed is None else observed == spec['property_compare']['value']
        values.append((p['effect'], truth))
    if any(effect == 'DENY' and truth is not False for effect, truth in values):
        return False
    return any(effect == 'PERMIT' and truth is True for effect, truth in values)


def walks(graph, catalog, user, bound):
    nodes = {n['id'] for n in graph['nodes'] if allowed(catalog, user, n, 'NODE')}
    edges = [e for e in graph['edges'] if e['source'] in nodes
             and e['target'] in nodes and allowed(catalog, user, e, 'EDGE')]
    answers = Counter()
    for length in range(1, bound + 1):
        for sequence in product(edges, repeat=length):
            if all(a['target'] == b['source'] for a, b in zip(sequence, sequence[1:])):
                answers[(sequence[0]['source'], sequence[-1]['target'])] += 1
    return answers
