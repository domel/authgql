"""Run correctness tests and generate the manuscript's measured tables."""
from pathlib import Path
import csv
import json
import unittest
from contextlib import redirect_stdout
import io


def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item


def requirements(name):
    # Reviewed mappings: policy-owner references are not element identifiers.
    mapping = {
        'aggregate_counts_only_authorized_bindings': 'R4, R8',
        'denied_sort_key_fails_before_sorting': 'R3, R7, R8',
        'exists_cannot_observe_hidden_patient': 'R4, R6, R8',
        'guarded_path_hides_remote_and_sealed_patients': 'R4, R7',
        'optional_match_null_extends_after_authorization': 'R4, R6, R8',
        'remove_uses_old_state_and_checks_new_state': 'R5',
        'researcher_cannot_dereference_identifying_property': 'R3',
        'static_plan_contains_guards_and_property_obligations': 'R3, R6',
        'whole_element_projection_is_an_opaque_reference': 'R3',
        'with_check_rejects_and_rolls_back_set': 'R5, R7',
        'hidden_intermediate_node_breaks_variable_length_path': 'R4',
        'article_style_exists_predicate_uses_session_user': 'R3, R7',
        'delete_policy_failure_precedes_nodetach_validation': 'R5, R6',
        'inserted_edge_and_endpoints_commit_together': 'R4, R5',
        'multi_element_insert_is_all_or_nothing': 'R5, R7',
        'plain_delete_is_nodetach_and_detach_is_explicit': 'R5',
        'deny_overrides_inherited_permit': 'R2, R7',
        'non_admin_introspection_redacts_predicates_and_dependencies': 'R9',
        'policy_dependencies_obey_restrict_and_cascade': 'R2, R7',
        'revoke_restrict_and_cascade_follow_delegation': 'R2',
        'role_hierarchy_is_transitive_and_acyclic': 'R2',
        'authorization_failure_precedes_read_only_mode_failure': 'R6',
        'authorization_state_is_fixed_at_transaction_start': 'R7',
        'authorized_write_in_read_only_transaction_raises_25g03': 'R5, R6',
        'rollback_discards_staged_graph_update': 'R5',
        'generated_catalogs_graphs_and_bounded_walks': 'R1, R2, R3, R4, R7',
        'activation_reopens_only_after_last_policy_disabled': 'R7',
        'all_three_valued_permit_deny_combinations': 'R7',
        'closed_scope_denies_omitted_broad_grantee': 'R7',
        'create_policy_requires_explicit_reference_even_for_admin': 'R2, R7',
        'explicit_reference_denial_overrides_owner_grant': 'R7',
        'invalid_dependency_remains_closed': 'R7',
        'lost_reference_denies_new_snapshot_not_existing_snapshot': 'R7',
        'multielement_set_checks_complete_poststate_and_rolls_back': 'R5',
        'multisupport_cascade_is_conservative': 'R2',
        'open_scope_preserves_object_only_access': 'R1',
        'predicate_whitelist_and_source_bounds': 'R7',
        'read_memoization_is_discarded_at_statement_boundary': 'R7',
        'reference_grant_allows_creation_and_loss_blocks_alter': 'R2, R7',
        'requester_metrics_are_redacted': 'R9',
        'runtime_budget_is_invalid_not_true': 'R7',
        'transitive_dependency_owner_loss_denies': 'R7',
        'unrelated_invalid_policy_does_not_deny_requester': 'R7',
    }
    return mapping[name.rsplit('.', 1)[1].removeprefix('test_')]


root=Path(__file__).resolve().parent
out=root/'results'; out.mkdir(exist_ok=True)
suite=unittest.defaultTestLoader.discover(str(root/'tests'))
names=[t.id() for t in flatten(suite)]
stream=io.StringIO()
result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
(out/'tests.txt').write_text(stream.getvalue())
assert result.wasSuccessful(), stream.getvalue()
(out/'tests.json').write_text(json.dumps({'test_methods':result.testsRun,
    'failures':len(result.failures),'errors':len(result.errors),'random_seeds':200,
    'oracle_multiset_comparisons':1800,'tests':names},indent=2)+'\n')
with (out/'test_inventory.csv').open('w',newline='') as handle:
    writer=csv.writer(handle); writer.writerow(['test_method','requirements','status'])
    for name in names: writer.writerow([name,requirements(name),'PASS'])
import evaluate
buffer=io.StringIO()
with redirect_stdout(buffer): evaluate.main()
(out/'hospital.json').write_text(buffer.getvalue())

report=json.loads((out/'benchmark.json').read_text())
assert len(report['cases'])==40
with (out/'benchmark.csv').open('w',newline='') as handle:
    fields=['family','nodes','edges','mode','policies','predicate','depth','hops',
            'branch','kind','delta','p50_ms','p95_ms','peak_extra_mib']
    writer=csv.DictWriter(handle,fieldnames=fields,extrasaction='ignore')
    writer.writeheader(); writer.writerows(report['cases'])

selected=[]
for c in report['cases']:
    label=None
    if c['family']=='size': label={'disabled':'Guards disabled','object':'Object only','policy':'One property policy'}[c['mode']]
    if c['family']=='policies' and c['policies'] in [10,100]: label=f"{c['policies']} property policies"
    if c['family']=='roles' and c['depth']==16: label='Role depth 16; one policy'
    if c['family']=='predicate' and c['predicate']=='exists3': label='One three-hop EXISTS policy'
    if c['family']=='branch' and c['branch']==16: label='Branch 16, hops 3'+('; memoized' if c['mode']=='memo' else '; uncached')
    if c['family']=='writes' and c['nodes']==100000: label='Clone only' if c['kind']=='clone' else 'Single-node SET with check'
    if c['family']=='writes' and c['nodes']==10000 and c.get('delta')=='all': label='10000-node SET with check'
    if label: selected.append((label,c))
lines=[r'\begin{table*}[t]',r'\caption{Selected interpreter measurements. Latency is in milliseconds; memory is additional traced Python allocations in MiB, excluding the input graph. Complete samples and all 40 configurations are in Online Resource~1.}',r'\label{tab:performance}',r'\small',r'\begin{tabularx}{\textwidth}{@{}Yrrrr@{}}',r'\toprule',r'Configuration & Nodes & p50 & p95 & Extra peak \\',r'\midrule']
for label,c in selected:
    lines.append(f"{label} & {c['nodes']} & {c['p50_ms']:.2f} & {c['p95_ms']:.2f} & {c['peak_extra_mib']:.2f} \\")
lines.extend([r'\bottomrule',r'\end{tabularx}',r'\end{table*}'])
# Two backslashes are required at the end of each generated LaTeX row.
lines=[line+'\\' if line.endswith('\\') and not line.endswith('\\\\') else line for line in lines]
(root.parent/'performance_table.tex').write_text('\n'.join(lines)+'\n')
print(stream.getvalue().splitlines()[-4:])
print(json.dumps(report['metadata'],indent=2))
