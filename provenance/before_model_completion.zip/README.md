# Online Resource 1: revised AuthGQL executable model and evaluation

Article: *AuthGQL: Standard-Compatible Authorization for the Graph Query Language*

Journal: International Journal of Information Security

Author: Dominik Tomaszuk, Faculty of Computer Science, University of Białystok,
Białystok, Poland; d.tomaszuk@uwb.edu.pl; ORCID 0000-0003-1806-067X.

This is a local revision supporting the revised manuscript. It is **not** the
unchanged Zenodo v1.0.0 release at https://doi.org/10.5281/zenodo.21862371.
The maintained original repository is https://github.com/domel/authgql-prototype.
The package is an in-memory semantic model, not an ISO-conforming GQL DBMS.

## Reproduce

Python 3.10 or later, standard library only. The recorded run used Python 3.10.12.
Run commands from this directory:

```sh
PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s tests -v
PYTHONDONTWRITEBYTECODE=1 python evaluate.py
PYTHONDONTWRITEBYTECODE=1 python benchmark.py --output results/benchmark-rerun.json
```

The benchmark can take several minutes, especially the bulk-update cases.
Keep reruns in a different file to preserve the supplied raw measurements.
The complete suite has 43 test methods. One method performs 1800 independent
oracle comparisons (200 seeds × 3 users × 3 hop bounds), not 1800 independent
test methods. `results/tests.txt`, `tests.json` and `test_inventory.csv` record
the executed inventory and outcomes. The six hospital workload results are in
`results/hospital.json`.

`collect_results.py` reruns correctness tests and generates the CSV inventory,
hospital JSON and the manuscript's `../performance_table.tex` from the supplied
benchmark data. Its manuscript-output path assumes the original submission
layout; it is not required to run the tests or benchmarks after extracting this
supplement separately.

## What changed

- An enabled graph/action/selector scope is closed independently of the
  requester. Missing grantee matches deny instead of falling back to object grants.
- Policy-owner reference authority is explicit, with mandatory target-graph
  dependencies and snapshot-dependent invalidation.
- GQL policy ASTs use an allowlist and source/size/path limits; counted expression
  and candidate work exhausts a fail-closed per-decision budget.
- Ordinary session responses redact metrics and internal cross-check outcomes;
  `SHOW METRICS` requires administrative authority.
- Targeted regression tests and an independent dictionary/Cartesian-walk oracle
  supplement the inherited internal authorized-view consistency route.

Legacy fixtures now explicitly grant reference authority to their policy owners.
There is no implicit system-owner bypass. The console and direct Python executor
are trusted experimental interfaces, not authenticated client-facing services;
identity selection and raw counters must not be exposed to ordinary clients.

## Benchmark interpretation

`results/benchmark.json` stores every sample, p50/p95, an independently traced
allocation peak, counters and environment/source metadata for 40 completed cases.
`benchmark.csv` is a flattened summary. Graph generation and parsing are excluded;
executor construction and policy compilation are included. Garbage collection
runs before each timer; normal automatic collection remains enabled.

The memory figure is **additional peak Python allocation**, not RSS and not
the memory occupied by the input graph. One separately traced execution supplies
this figure. Instrumented timings in its metrics are not the untraced latency
samples. All-permitting synthetic policies keep overhead comparisons at equal
output cardinality; functional denial tests answer a different question.

The initial run also attempted a 100000-node bulk SET, but it was interrupted
before any complete measurement was recorded after inspection exposed quadratic
dictionary-union remapping. No result or timeout value is imputed for that case.
The distributed benchmark bounds bulk SET to 1000/10000 nodes, while scans,
clone-only and single-node updates reach 100000 nodes. No million-node result
is supplied.

The session metric-redaction patch followed the benchmark run and is not on the
direct-executor measurement path. `provenance/session_before_redaction.py.txt`
preserves the earlier session file and matches its hash in the raw report; all
other recorded package source hashes match the measured files. The harness's
only subsequent configuration change excludes the uncompleted bulk case.

The read-only memoization and disabled-authorization adapters are exclusively
benchmark tools. Memoization is discarded per statement and never used for
updates or cross-transaction cache reuse. The disabled adapter must not be
enabled through an untrusted API.

## Boundaries

The model retains legacy `*m..n` input, a 12-hop cap, one JSON edge `type`, and
restricted expression/query forms. It does not implement general GQL path values,
explicit match/path mode portability, procedures, graph types, label mutation,
multi-graph policies, durable recovery, concurrent execution, a native optimizer,
or storage-level non-access. It uses full graph copies for staging/publication.
The independent oracle covers generated equality-policy bounded walks only.

Synthetic data only; no patient records or credentials are included. MIT license
terms are in `LICENSE`.
